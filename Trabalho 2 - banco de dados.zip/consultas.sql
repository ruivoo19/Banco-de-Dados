-- Consulta 1: Mostrar todos os materiais
select h.idmaterial, h.modelohardware, h.tipohardware
	from hardware h 
	join material m	on h.idmaterial = m.idmaterial
	order by modelohardware asc

-- Consulta 2: Listar os softwares para dispositivos mobiles
select m.idmaterial, s.plataformasoftware, s.versaosoftware, m.marcamaterial
	from software s
	join material m on s.idmaterial = m.idmaterial 
	where plataformasoftware in ('android', 'IOS')

-- Consulta 3: 
select m.idmaterial, p.modeloperiferico, p.tipoperiferico
	from perifericos p
	join material m	on p.idmaterial = m.idmaterial
	order by modeloperiferico asc

-- Consulta 4:
select m.idmaterial, p.modeloperiferico, p.tipoperiferico
	from perifericos p
	join material m	on p.idmaterial = m.idmaterial
	union
	select h.idmaterial, h.modelohardware, h.tipohardware
	from hardware h 
	join material m	on h.idmaterial = m.idmaterial
	order by modeloperiferico asc
	
-- Consulta 5: Visitas envolvendo todas as informações 
select v.horavisita, v.datavisita, pv.nome as nomevisitante, pi.nome as nomeinstrutor
from visita v
join visitante ve on ve.idVisitante = v.idvisita
join pessoa pv on pv.cpf = ve.cpf
join instrutor i on i.idinstrutor = v.idinstrutor
join pessoa pi on pi.cpf = i.cpf
	
-- Consulta 6: Listar visitas de instituições
select v.horavisita, v.datavisita, i.*
from visita v
join instituicao i on i.idinstituicao = v.idinstituicao 

-- Consulta 7: Listar as opinioes de todos os visitantes e suas fotos (CPF)
select v.cpf, a.notaavaliacao, a.descricaoavaliacao
from avaliacao a
inner join visitante v on a.idvisitante = v.idvisitante
	
-- Consulta 8: Listar todas as oficinas com informações das pessoas que assistiram
SELECT o.idoficina, o.dataoficina, o.horaoficina, o.idinstrutor, i.cpf, o.idvisitante, v.cpf
FROM oficina o
FULL JOIN instrutor i ON o.idinstrutor = i.idinstrutor
FULL JOIN visitante v ON o.idvisitante = v.idvisitante

-- Consulta 9: Listar doações e informações do doador
SELECT d.valor, d.iddoador, ddr.cpf, ddr.stts, p.genero, p.datanascimento, p.nome
FROM doacao d
join doador ddr on d.iddoador = ddr.iddoador
join pessoa p on ddr.cpf = p.cpf
WHERE EXISTS (
    SELECT 1 
    FROM doacao d2 
    WHERE d2.tipodoacao = 'material' 
    AND d.valor = d2.valor
) order by iddoador asc

--Consulta 10: Listar todas as formas de remuneração em dinheiro
SELECT d.valor AS valor 
FROM doacao d
WHERE EXISTS (
    SELECT 1 
    FROM doacao d2 
    WHERE d2.tipodoacao = 'dinheiro' 
    AND d.valor = d2.valor
)
UNION ALL
SELECT p.valorpatroc AS valor 
FROM patrocinador p
WHERE EXISTS (
    SELECT 1 
    FROM patrocinador p2 
    WHERE p2.tipopatroc = 'dinheiro' 
    AND p.valorpatroc = p2.valorpatroc
);

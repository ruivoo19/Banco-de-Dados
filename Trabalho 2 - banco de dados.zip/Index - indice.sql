CREATE INDEX maisde4estrelas
on avaliacao using btree (notaavaliacao, idavaliacao) where notaavaliacao > 8;

select * from avaliacao where notaavaliacao > 8